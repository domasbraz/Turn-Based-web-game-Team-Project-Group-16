First ever prototype for the game

Features:
-card system
-knight class with 2 skills
-enemy class with 1 skill

How To Run:
1. Make sure you have the "Game" folder with all its files saved on your machine.
2. Open "game.html" in your browser of choice.

OR if using live server from vscode, make sure you have the "Game" folder opened.