function userKnightInput()
{
    let knightAmount = parseInt(prompt("Enter how many knights will be in battle (max 4)"));

    if (knightAmount > 0 && knightAmount < 5)
    {
        createKnights(knightAmount);
    }
    else
    {
        alert("'" + knightAmount + "' is an invalid value.\r\nPlease enter a value between 1 and 4");
        userKnightInput();
    }
}

function userEnemy1Input()
{
    let enemy1Amount = parseInt(prompt("Enter how many enemies will be in battle (max 4)"));

    if (enemy1Amount > 0 && enemy1Amount < 5)
    {
        createEnemy1s(enemy1Amount);
    }
    else
    {
        alert("'" + enemy1Amount + "' is an invalid value.\r\nPlease enter a value between 1 and 4");
        userKnightInput();
    }
}

userKnightInput();
userEnemy1Input();



function createKnights(amount)
{
    for (let x = 1; x <= amount; x++)
    {
        createUnitKnight(x);
    }
}

function createEnemy1s(amount)
{
    for (let x = 1; x <= amount; x++)
    {
        createUnitEnemy1(x);
    }
}

setTurns();

console.log(playerTurns + " " + aiTurns);